/*
Homework 1#: Guess the run-time output

Pass over the code line by line by yourself
Decide What is the output of this code?

Then run it and compare against yours!
*/

#include<iostream>
using namespace std;

int main()
{
	cout<<"\n\nGuess the "
		<<"output\n---\n";

	cout<<10+20-5<<endl;
	cout<<"14/2"<<"\n";
	cout<<17-10<<"\n";
	cout<<"endl";
	cout<<"\nPractice makes perfect";

	//cout<<"The way to get started is to quit talking and begin doing";

	return 0;

	cout<<"\n\nBye\n\n";
}
