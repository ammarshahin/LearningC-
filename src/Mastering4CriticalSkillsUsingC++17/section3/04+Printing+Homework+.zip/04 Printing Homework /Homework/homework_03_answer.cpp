#include<iostream>				// <iostream> 	NOT 	<stream
using namespace std;			// std;    		NOT   	STD





int main() {	// main NOT maIN          ... it is ok to have { here

	// Don't print outside main
	cout <<"work smart not hard\n";

	// Add simicolon
	cout << "Children must be taught how to think, not what to think\n";

	// Be careful from double quotes in middle of string. Use \" instead of "    [later name: escape char]
	cout << "We worry about what a child will become \"tomorrow\", yet we forget that he is someone today\n";

	// << NOT <
	cout << "Children are not things to be molded"<<", but are people to be unfolded\n";

	// endl NOT end
	cout << "Each day of our lives we make deposits in the memory banks of our children."<<endl;

	// Be careful from the 2 extra "
	cout      << "It is easier to build strong children than to repair broken men"<<"\n";

	// << NOT >>
	cout << "Children need models rather than critics\n";

	// cout NOT out
	cout<<"Children have never been very good at listening to their elders, but they have never failed to imitate them";

	// << not <
	cout << "Children are our most valuable resource\n";


	// Add return 0;
	return 0;

	// Add }
}
