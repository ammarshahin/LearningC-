/*
Homework 2#: Write code to print the following
A) A triangle with angel 90 degree
*/

#include<iostream>
using namespace std;

int main()
{
	cout<<"*"<<endl;
	cout<<"* *"<<endl;
	cout<<"* * *"<<endl;
	cout<<"* * * *"<<endl;
	cout<<"* * * * *"<<endl;

	return 0;
}
